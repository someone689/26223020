#!/bin/bash

echo "Q5"
du -sh .
