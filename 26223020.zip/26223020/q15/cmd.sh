#!/bin/bash

echo "Q15: "
du -h *txt *pdf
