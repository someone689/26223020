#!/bin/bash

echo "Q6 - files modified in the last week"
find /mnt/c -mtime -7

echo "Q6 - files modified in the last 2 hours"
find /mnt/c -mmin -120
