#!/bin/bash

echo "Q2"
awk "NR>=15 && NR<=20" file.txt
