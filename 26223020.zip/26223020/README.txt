Name: Arpit Sharma
Roll no: 26223020

How to execute:

1. Go inside question directory using ` cd dirname `
2. Execute cmd file using ` bash cmd.sh `
