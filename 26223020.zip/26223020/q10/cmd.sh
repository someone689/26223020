#!/bin/bash

echo "Q10: "
read -p "Enter roll: " roll && awk -F, -v r="$roll" '$1==r {print "Grade:"$2}' CS100.txt
