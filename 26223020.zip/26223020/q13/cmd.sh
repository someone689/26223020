#!/bin/bash

echo "Q13: date in mm/dd/yy"
date "+%x"
