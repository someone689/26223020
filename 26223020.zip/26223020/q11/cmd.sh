#!/bin/bash

echo "Q11: files except pdf and txt"
ls | grep -v -E '\.(pdf|txt)$'
