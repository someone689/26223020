#!/bin/bash

echo "Q9 - no. of words in first 10 lines: "
head -n 10 file.txt | wc -w
