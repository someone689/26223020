#!/bin/bash

echo "Q7 - before"
cat file.txt

sed -i 's/ /\t/g' file.txt

echo "Q7 - after"
cat file.txt
