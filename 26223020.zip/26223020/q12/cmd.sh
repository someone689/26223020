#!/bin/bash

echo "Q12 - for changing float to int"
echo "Before:"
cat add.c
sed -i 's/float/int/g' add.c
echo "After: "
cat add.c

echo "Q12 - for changing %f to %d"
echo "Before: "
cat add.c
echo "After: "
sed -i 's/%f/%d/g' add.c
cat add.c
