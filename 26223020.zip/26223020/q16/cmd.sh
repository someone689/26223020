#!/bin/bash

echo "Q16: "
grep -E -o "\b([0-9]{1,3}\.){3}[0-9]{1,3}\b" file.txt
