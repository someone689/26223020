#!/bin/bash

echo "Q4"
find /usr/bin -type f -name "a*" | sort -rh | head -n 3
