#!/bin/bash

echo "Q3"
export TZ="Asia/Kolkata"
date "+%a %b %d %r %Z %Y"
