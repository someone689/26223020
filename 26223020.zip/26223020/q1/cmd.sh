#!/bin/bash

echo "Q1-1"
grep -oiE "\b[a-zA-Z]+ [a-zA-Z]+h\b" user.txt

echo "Q1-2"
grep -oiE "[a-z0-9]+@[a-z0-9].[a-z]{2,}" user.txt

echo "Q1-3"
grep -oiE "[0-9]{4} [0-9]{4} [0-9]{4} [1][5][6][2]" user.txt

echo "Q1-4"
grep -oiE "(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[0-2])-(200[0-4])" user.txt
