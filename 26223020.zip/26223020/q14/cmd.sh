#!/bin/bash

echo "Q14 - merge"
cat *.txt > merge.txt
echo "After merging: "
cat merge.txt
